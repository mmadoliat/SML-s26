library(MASS)
varnames<-c("FL","RW","CL","CW","BD")
Crabs <- crabs[,varnames]

Crabs.pca <- princomp(Crabs)
summary(Crabs.pca)
loadings(Crabs.pca)

pairs(Crabs)
pairs(predict(Crabs.pca))

Crabs.class <- factor(paste(crabs$sp,crabs$sex,sep=""))
Crabs.class
pairs(Crabs,col=unclass(Crabs.class))
pairs(predict(Crabs.pca),col=unclass(Crabs.class))

Z<-predict(Crabs.pca)
plot(Comp.3~Comp.2,data=Z,col=unclass(Crabs.class))

biplot(Crabs.pca,scale=1)

# Connections between PCA, ED of S, and SVD of X

X <- scale(Crabs,center = T, scale = F)
eS <- eigen(var(Crabs))
eXtX <- eigen(t(X)%*%X)
sX <- svd(X)

loadings(Crabs.pca)
eS$vectors
eXtX$vectors
sX$v

summary(Crabs.pca)
sqrt(eS$values/200*199)
sqrt(eXtX$values/200)
sX$d/sqrt(200)

summary(Crabs.pca)
eS$values/sum(eS$values)
eXtX$values/sum(eXtX$values)
sX$d^2/sum(sX$d^2)
