encrypt <- function(plain) {
  cipher <- ""
  for (i in 1:nchar(plain)) {
    ch <- substr(plain, i, i)
    cipher <- ifelse(ch == " ", paste0(cipher, ch),
      paste0(cipher, toupper(letters[((utf8ToInt(ch) - 60) %% 26) + 1]))
    )
  }
  return(cipher)
}

print(encrypt("FOUR SCORE AND SEVEN YEARS AGO"))