### (Some Brain Teasers)

# TRUE or FALSE?
1==1
3-2==1
0.3-0.2==0.1
0.4-0.2==0.2

# TRUE or FALSE?
0==0
1-1==0
1-1+.1==.1
1+.1-1==.1

# https://www.omnicalculator.com/math/binary-fraction
# https://www.truenorthfloatingpoint.com/problem

as.integer(2^31-1)
as.integer(2^31)

# One last example
n <- 1000; M <- 2^100
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")

A <- rnorm(n,mean = M,sd = M)
B <- rnorm(n,mean = -M,sd = M)
hist(A,col=c1,xlim = range(c(A,B)))
hist(B,col=c2,add=T)

all.equal(A+B-A-B,rep(0,n))
sum(abs(A+B-A-B))
sum(A+B-A-B==0)
boxplot(A-A+B-B, main="A-A+B-B")
boxplot((A+B-A-B), main="A+B-A-B")
boxplot(jitter(A+B-A-B), main="A+B-A-B")

### Example 13.1 (Identical and nearly equal)

isTRUE(all.equal(.2, .3 - .1))
all.equal(.2, .3)          #not a logical value
isTRUE(all.equal(.2, .3))  #always a logical value

x <- 1:4
y <- 2
y == 2
x == y  #not necessarily a single logical value
identical(x, y)  #always a single logical value
identical(y, 2)


### Example 13.2 (Ratio of two large numbers)

n <- 400
(gamma((n-1)/2) / (sqrt(pi) * gamma((n-2)/2)))
exp(lgamma((n-1)/2) - lgamma((n-2)/2)) / sqrt(pi)



### Example 15.1 (Benchmarking methods to generate a sequence)

    s1 <- 1:10
    s2 <- seq(1, 10, 1)
    s3 <- seq.int(1, 10, 1)
    df <- data.frame(s1=s1, s2=s2, s3=s3)
    str(df)

    library(microbenchmark)
    library(ggplot2)
    
    n <- 1000
    mb <- microbenchmark(
      seq(1, n, 1),
      seq.int(1, n, 1),
      1:n
    )
    
    mb
    autoplot(mb)  # display a violin plot

### Example 15.2 (Benchmarking methods to initialize a vector)

    n <- 100
    mb2 <- microbenchmark(
      numeric = numeric(n) + 1,
      rep = rep(1, n),
      seq = seq(from=1, to=1, length=n),
      ones = matrix(1, nrow=n, ncol=1),
      as.ones = as.matrix(rep(1, n))
    )
    
    mb2
    autoplot(mb2)  # display a violin plot
    
### Example 15.3 (Timings of two multivariate normal generators)

  library(rbenchmark)
  library(MASS)
  library(mvtnorm)
  n <- 100          #sample size
  d <- 30           #dimension
  N <- 2000         #iterations
  mu <- numeric(d)

  benchmark(
      columns = c("test", "replications", "elapsed", "relative"),
      replications = 2000,
      cov = {S <- cov(matrix(rnorm(n*d), n, d))},
      mvrnorm = mvrnorm(n, mu, S),
      rmvnorm = rmvnorm(n, mu, S)
  )

### Example 15.4 (Profiling with Rprof)

  hilbert <- function(n) { 
    i <- 1:n
    1 / outer(i - 1, i, "+")
  }

  Rprof("pr.out", line.profiling = TRUE)
  svd(hilbert(1000))
  Rprof(NULL)
  summaryRprof("pr.out")


### Example 15.17 (A first Rcpp experiment)

# In RStudio use the menu
# File > New File > C++ file to display this code

### Example 15.18 (cppFunction)

    library(Rcpp)
    
    set.seed(1)
    x <- matrix(rnorm(20), nrow = 5, ncol = 4)
    
    cppFunction('double vecnorm(NumericVector v) {
      // compute the Euclidean norm of vector v
      int d = v.size();
      double s = 0.0;
      for (int i = 0; i < d; i++)
        s += v(i) * v(i);
      return sqrt(s);
    }')
    
    print(vecnorm(x[, 1]))
    print(apply(x, MARGIN = 2, FUN = "vecnorm"))


### Example 15.19 (sourceCpp)

# Create the C++ source file "printme.cpp" by editing the template
# in RStudio menu: File > New File > C++
  library(Rcpp)
  sourceCpp("printme.cpp")
    
  x <- sample(1:5)
  print_me(x)

