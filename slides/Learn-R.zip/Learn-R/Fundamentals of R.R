################
#
# FUNDAMENTALS OF R
#
#---
#
# * R is an INTERPRETED LANGUAGE:
#     Users type expressions and see results immediately.
#     Example:
        for (i in 1:10) if(i%%2==0) print(i)
#     As opposed to:
#     - compiled languages (C, Fortran)
#     - point-and-click software (such as SAS' JMP)
#    
#---
#
# * R is HIGH-LEVEL:
#     It operates on complex data structures such as 
#     vectors, matrices, arrays, lists, dataframes,
#     as opposed to C and Fortran that operate on individual numbers only.
#     (This requires some getting used to for C programmers.)
#    
#---
#
# * PRIMARY BEHAVIOR: Whatever is typed, print the results.
      2
      print(2)   # same
#   Why is there '[1]' preceding the results?
#   Because R considers numbers as vectors of length 1.
#   Compare with a vector of length greater than 1:
      1:3
      print(1:3)
#
#---
#
# * SYNTAX:
#   - Largely scientific/math notation; base 10.
#   - A wealth of functions.
#   - Comments run from a "#" to the end of the line; no multiline comments.
#   - Spaces are irrelevant, except inside strings:
        2+3; 2  +    3
#   - Statements can run over multiple lines:
        2 + 3 +     #
        4           # One statement.
#     But if a statement is syntactically complete at
#     the end of the line, it won't continue:
        2 + 3       #
        + 4         # Two statements.
#   - Statements can be separated by ";".
        2; 3^3; sqrt(9)
#    
#---
#
# * BASIC DATA TYPES:
#
#   - DOUBLE PRECISION (there is no integer type and no single precision).
#     Integers are represented as doubles, although the print function
#     shows them as integer:
        -2.000
        1E5
        2E-3
#     Doubles are 64 bits or 8 bytes.
#     They permit the usual unary and binary operations as well as
#     analytic functions:
#       +, -, *, /, %%, %/%, ^, log, sqrt, sin, acos...
        2+3            # Add.
        5.3*1E10       # Multiply.
        10%%3          # Modulo.
        log(2.718282)  # Log of the number 'e'; 'log' is e-based.
        log10(10)      # 10-based log
        pi             # That's the number 'greek pi', 3.14159
        sin(pi/2)      # Angles are to be given in arcs, not degrees.
        sin(pi)        # Dito.
        acos(0)        # This is the inverse of cos, arccos, hence pi/2.
        pi/2
#
#   - STRINGS: can be single or double quoted, but the print function
#     uses double quotes.
        'a'; "a"; 'abc'; "abc"
#     (In C and Python strings are character vectors.
#      In R strings are basic types; there is no single character type.
#      Characters are just strings of length 1.
#      There is no indexed access to individual characters and
#      substrings in R; one uses the "substring" function instead:
         substring("abcxyz",4,6)
#     There are two character vectors that contain the lower and
#     upper case letters:
        letters; LETTERS
#
#   - LOGICAL values: have two names each, but the print function
#     always uses the longer.
        TRUE; FALSE; T; F
#     They are implemented as the values 1 and 0 for T and F, respectively.
#     They are the result of the usual comparisons: <, >, <=, >=, ==, !=
        1<2; 1>2; "ab" <= "abcd"
        "ab" > "ac"; "ab" != "AB"
        "ab" != 2; 0==F; 1==T
#
#   - MISSING values NA, Inf, -Inf:
        NA; NaN; Inf; -Inf; 1/0; Inf==1/0; 0/0
#     Watch out: the following does not give T!!!
        NA==1
#
#
#---
#
# * R is a FUNCTIONAL LANGUAGE:
#   Functions return values that in turn can be arguments to functions.
#   Expressions evaluate inside out, e.g., (log(2*2.5))^3:
        2.5; 2*2.5; log(2*2.5); log(2*2.5)^3; plot(rnorm(100)^2)
#
#---
#
# * STATEMENTS/EXPRESSIONS:
#     There are two types of expressions: assignments and side effects.
#     1) Assignments allocate data structures and
#        make variables point to them.  
           x <- 1:3   # Allocate a vector 1,2,3 and make 'x' point to it.
#     2) Side effects are essentially display operations 
#        such as printing, plotting, showing help; unlike assignments,
#        they don't change the computational state of the R system.
           print(x)
           plot(x)
           help("+")    # Show the help page of addition.
           help(sqrt)   # Show the help page of the square root function.
           help("sqrt") # Dito.
#     3) Composite Statements:
           {print(1); plot(1:10)}
#        Will be needed in loops and functions.
#
#
#   - Assignments to variables come in four equivalent syntactic forms:
#       x <- ...
#       x = ...
#       ... -> x
#       assign("x",...)
#     Examples:
        x <- sqrt(2 * 3)    # Root of product of 2 and 3
        x = sqrt(2 * 3)     # Both can be used: '=' and '<-'
        sqrt(2 * 3) -> x    # This can be used, too, if you must...
        y <- c(1,3,10,1,1,1111,0,1,1)  # combine 1,3,10... into a vector 'y'
        z <- 1:3           # Assign the vector containing 1,2,3 to a 'z'.
        assign("x", sqrt(2*4))
#     Note that variables jump into existence upon assignment.
#     Unlike C and Fortran, there is no need to declare variables.
#     The variables are not 'typed', that is, any variable can
#     point to data of any type, such as numbers, logicals, vectors,...
#
#---
#
# * HELP: help(function) or help("function") shows function documentation.
        help(sqrt)
#     In the output of this function, check out the section
#     with header "See Also:".  It will tell you that you
#     can find related functions by calling
        help("Arithmetic")
        help("log")
        help("sin")
        help("Special")
#          
        help(c)
        help("c")   # Same as help(c)
        help("*")   # help(*) does not work
#
# * APROPOS: apropos("char") lists all functions whose name contains
#     the string "char".
        apropos("char")
#     This is often useful for finding related functions.  
#     Apropos combined with the section "See Also:" in the output
#     of help() is a powerful tool for searching functions.
#     There are about 1,700 built-in functions, and more if you
#     download special-purpose packages from the R website.
#
#---
#
# * MANAGEMENT OF DATA AND FUNCTIONS: 
#     - Listing R objects, both data and functions: either of
          ls();  objects()
#       This lists all data structures and functions that YOU defined.
#     - Removing data and functions:
          x <- 1:10
          rm(x)
          x
#     - Looking for partly remembered data and functions:
#       In case you remember only part of a name, you can look it up
#       with a partial pattern:
          ls(pattern="last")
#       This will list any dataset whose name contains "last"
#       such as 'last.warning'.
#     - List all functions that come with the base package of R:
            ls("package:base")   # Almost 1700 functions...
#     - About packages: 
#     . Packages are namespaces for data AND functions.
#       (You can't have a dataset 'x' and a function 'x' at the same time.)
#     . You can list the packages in your environment:
          search()
#     . Everytime you download and install a package from the R site,
#       a new entry will be shown by 'search()'.  There are numerous
#       contributed packages for modern statistical methods.  
#     . When you use a name, R goes through the search list
#       shown by 'search()', package by package, stopping when
#       it finds the name.  This implies that the same name can appear
#       in multiple packages, but only the one in the first package
#       will be found.
          ls <- 2:5   # mask 'ls' in "package:base" with user data
          ls
          rm(ls)      # remove user data, unmasking the function 'ls()' 
          ls
#
#---
#
# * QUITTING:
        q()
#     R asks whether you want to save the workspace; 
#     usually you say "yes".  Splus simply quits.
#
#---
#
# * SEMANTICS:
#     Every assignment creates a copy of the assigned object.
#     Assignment is by value, not by reference (unlike Python and C).
        a <- c(1,3,5) # 
        a 
        b <- a        # 'b' gets its own copy.
        b             # We couldn't tell from this, though.
        a[1] <- 2     # Assign the value 2 to the first element of 'a'.
        # This yields a test of whether 'a' and 'b' point to the same object.
        # If they did, then 'b' would also have 2 in the first position.
        a             # We know this.
        b             # Uhu!  'b' was not changed by 'a[1] <- 2'.
        # Therefore, 'b' has its own copy.
#
################