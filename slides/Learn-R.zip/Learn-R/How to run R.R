######## STATISTICS 489 ########################################
######## STAT METHODS IN FINANCE ###############################
################################################################
#
#                      INTRO TO R/SPLUS
#
# The R website:
#
#   http://www.r-project.org
#
#   (Google "R" -> one of the first entries)
#
# Downloading R:
#
#   ->  Sidebar "Download": CRAN
#   ->  "United States of America": http://cran.us.r-project.org
#   ->  Pick a mirror site
#   ->  Download R for Windows
#   ->  base
#
#   The base is really just the base.  There are many contributed
#   library packages whose binaries can be downloaded from
#
#   ->  Sidebar "Packages"
#
#   You will not have to download them explicitly, though;
#   there are R functions that allow you to get them while running R.
#
################
#
# LITERATURE:
#
# - From the R website:
#
#   ... ->  Manuals  [The first item is a 100 page book
#                     by Venables and Smith.]
#   ... ->  FAQs     [Check here when you have problems.]
#   ... ->  Contributed   [Other intros.]
#   ... ->  The R Journal
#   ... ->  Books
#
################
#
# OPERATION OF R:
#
# 0) Go to the class web page and download the lecture note files.
#    Save in a directory that is created for this course.
#
# 1) Open up an R window by clicking on the R icon.
#    File -> Open script -> Select the note file you downloaded.
#    Copy R code from this file into the R interpreter window.
#    Use shortcuts: highlight lines, hit <Ctrl>-C in the editor,
#                   then move to the R window and hit <Ctrl>-V.
#    Simpler shortcuts: highlight lines, hit <Ctrl>-R in the editor
#    Examples:
       1+2
       1:10
       2^(1:20)
       runif(10)
       rnorm(10)
       1:10 + rnorm(10)
#    Repeat...
# 2) Experiment with R code
#      by editing THIS file in the editor window, or
#      by editing the command line in the R window (if it's one-liners).
#
# Commands for line editing in the R interpreter window:
#  (It would be better to edit the script file.)
#  Note: "^p" means you hold down the modifier key <Ctrl> and hit "p",
#        just like the modifier key <Shift> used for capitalization
#  ^p get back the previous command line for editing and executing
#     repeating ^p goes further back in the command history
#  ^b step back one character in the command line
#  ^f step forward one character in the command line
#  ^a move to the beginning of the line
#  ^e move to the end of the line
#  ^d or <Delete> to delete the character under the cursor
#  ^h or <Backspace> to delete the previous character
#  ^k kill the rest of the line starting from the cursor
#  otherwise: you are in insert mode
#  You may use arrow keys, Delete or Backspace
#
################################################################
#
# R versus Splus:
#
# * For most users they look almost the same.
# * There are semantic differences, though, when one writes functions.
# * Data handling:
#   - R keeps all data in main memory.
#   - Splus writes data out to files after every execution.
#   => Splus is safer, but R is faster.
# * Availability and history:
#   - Splus is a commercial product of the Insightful company,
#     www.splus.com, an extension of the S language developed
#     at former AT&T Bell Labs.
#   - R is freeware, under ongoing development by strong academics.
#     Its syntax and most functions are inherited from the S language.
#     Some deep semantics are inherited from LISP.
#
# From now on we will only refer to R, although most everything holds
# for Splus as well.
#
###############################################################